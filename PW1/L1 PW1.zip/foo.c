#include "foo.h"
#include "foo.h"

int main() {
	struct foo f;
	return 0;
}
