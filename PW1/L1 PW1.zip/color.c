#include <stdio.h>
#include "color.h"

void C_print (Color c) {
	printf("(%d, %d, %d)\n", c.red, c.green, c.blue);
}

Color C_new (int red, int green, int blue) {
	Color tempColor = {red, green, blue};
	return tempColor;
}

int clamp (int n) {
	if (n < 0) return 0;
	if (n > 255) return 255;
	return n;
}

Color C_multiply (Color c, float coef) {
	if (coef > 0) {
		c.red = clamp (c.red * coef);
		c.green = clamp (c.green * coef);
		c.blue = clamp (c.blue * coef);
	}
	return c;
}

Color C_negative (Color c) {
	c.red = 255 - c.red;
	c.green = 255 - c.green;
	c.blue = 255 - c.blue;
	return c;
}

Color C_permute (Color c) {
	int temp = c.red;
	c.red = c.blue;
	c.blue = c.green;
	c.green = temp;
	return c;
}
