#include <stdio.h>
#include "color.h"
#include "image.h"
#include "ppm.h"

int main () {
	Color *img;
	int nbpixels;
	struct ppm p;

	p = PPM_new("rebelle.ppm");
	nbpixels = PPM_nbPixels(p);
	img = PPM_pixels(p);

	I_negative(img, nbpixels);
	PPM_save(p, img, "negative.ppm");
	I_negative(img, nbpixels);
	I_coef (img, nbpixels, 1.2);
	PPM_save(p, img, "coef.ppm");
	I_coef (img, nbpixels, 0.8333);
	I_permute (img, nbpixels);
	PPM_save(p, img, "permute.ppm");

	return 0;
}

