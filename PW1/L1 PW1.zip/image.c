#include "image.h"

void I_print (Color *img, int nb_pixels) {
	for (int i = 0; i < nb_pixels; i++) C_print (img[i]);
}
void I_coef (Color *img, int nb_pixels, float coef) {
	for (int i = 0; i < nb_pixels; i++) img [i] = C_multiply (img[i], coef);
}
void I_negative (Color *img, int nb_pixels) {
	for (int i = 0; i < nb_pixels; i++) img [i] = C_negative (img[i]);
}
void I_permute (Color *img, int nb_pixels) {
	for (int i = 0; i < nb_pixels; i++) img [i] = C_permute (img[i]);
}
