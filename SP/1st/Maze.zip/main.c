#include <stdio.h>
#include "Maze.h"
#include "Cell.h"

int main()
{
	int width, height;//Width and height of the maze
	printf("Width of maze: ");scanf("%d", &width);
	printf("Height of maze: ");scanf("%d", &height);
	Maze mz = MZ_new(width, height, MZ_HARD);

	Cell entrance = CL_entrance(mz);
	Cell exit = CL_exit(mz);

	Cell *solution = NULL;
	int cells = width * height;
	short been[cells];//The variable in which we have information whether we have been in given cell or not(1 for visited cells and 0 for not visited)
	for (int i = 0; i < cells; ++i)//For loop to initialize all the values of been as 0
		been[i] = 0;
	int steps = 0;
	int max_steps;
	CL_calloc (mz, entrance, exit, &solution, steps, been, width);//Calloc of solution array
	for (int i = 0; i < cells; ++i)//For loop to initialize all the values of been as 0 since after calloc some cells were visited
		been[i] = 0;
	CL_findExit (mz, entrance, exit, solution, steps, been, width, &max_steps);//Finding exit and writing all the path into solution
	CL_setSolution (mz, solution, max_steps);
	MZ_saveImg(mz, "myMaze.ppm");
	MZ_free(mz);

	return 0;
}
