

#ifndef _VGORU_H_
#define _VGORU_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct
{
	int nb_ugeqpfgs_depuis_epoch, cppgg, oqku, lqwt, jgwtg, okpwvg, ugeqpfg;
} Vgoru;


Vgoru Tpqwx();
void VchhkejgFcvg(Vgoru t, char *temps);

#endif
