#include <stdio.h>
#include <stdlib.h>
#include "DistField.h"

DistField DF_new(int Nx, int Ny) {
    DistField df;
    df.arr = (int*)calloc(Nx*Ny, sizeof(int));
    df.width = Nx;
    df.height = Ny;
    for (int i = 0; i < Ny; i++) {
        for (int j = 0; j < Nx; j++)
            df.arr[Nx*i+j] = DF_INFINITY;
    }
    return df;
}

int DF_get(DistField df, int x, int y) {
    return df.arr[df.width*y+x];
}

void DF_set(DistField df, int x, int y, int val) {
    df.arr[df.width*y+x] = val;
}

void DF_show(DistField df, char *label) {
    printf("---------------%s---------------\n", label);
    for (int i = 0; i < df.height; i++) {
        for (int j = 0; j < df.width; j++)
            printf("%d ", DF_get(df, j, i));
        printf("\n");
    }
}

bool DF_propagate(DistField df, Cell c1, Cell c2) {
    if (df.arr[df.width*c2.x+c2.y] > df.arr[df.width*c1.x+c1.y] + 1) {
        df.arr[df.width*c2.x+c2.y] = df.arr[df.width*c1.x+c1.y] + 1;
        return TRUE;
    }
    return FALSE;
}

bool DF_propagatableLinkedCell(Maze mz, DistField df, Cell c, Cell *lnkneigh) {

}
