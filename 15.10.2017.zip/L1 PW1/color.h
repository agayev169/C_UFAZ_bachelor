#ifndef BLAH
#define BLAH

typedef struct {
	int red, green, blue;
} Color;

void C_print (Color c);
Color C_new (int red, int green, int blue);
int clamp (int n);
Color C_multiply (Color c, float coef);
Color C_negative (Color c);
Color C_permute (Color c);

#endif
