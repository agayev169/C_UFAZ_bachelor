#include <stdio.h>
#include "color.h"

void I_print (Color *img, int nb_pixels);
void I_coef (Color *img, int nb_pixels, float coef);
void I_negative (Color *img, int nb_pixels);
void I_permute (Color *img, int nb_pixels);
