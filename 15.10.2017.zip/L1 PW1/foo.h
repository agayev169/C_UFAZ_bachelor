#ifndef BLAH
#define BLAH

struct foo {
int x, y;
};

#endif
