#include <stdio.h>
#include "color.h"
#include "image.h"
#include "ppm.h"

char* concat(const char *s1, const char *s2)
{
    char *result = malloc(strlen(s1)+strlen(s2)+1);
    strcpy(result, s1);
    strcat(result, s2);
    return result;
}

int main () {
	Color *img;
	int nbpixels;
	struct ppm p;

	char* fileName;
	printf("Write a name of ppm file with format: ");
	scanf ("%s", &fileName);

	p = PPM_new(&fileName);
	nbpixels = PPM_nbPixels(p);
	img = PPM_pixels(p);

	I_negative(img, nbpixels);
	printf("Name of the negative image: ");
	char* negative;
	scanf("%s", &negative);
	PPM_save(p, img, &negative);
	I_negative(img, nbpixels);
	I_coef (img, nbpixels, 1.2);
	printf("Name of the coefficient image: ");
	char* coef;
	scanf("%s", &coef);
	PPM_save(p, img, &coef);
	I_coef (img, nbpixels, 0.8333);
	I_permute (img, nbpixels);
	printf("Name of the permite image: ");
	char* permite;
	scanf("%s", &permite);
	PPM_save(p, img, &permite);

	return 0;
}

