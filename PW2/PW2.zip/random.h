#ifndef RANDOM
#define RANDOM

#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define N 20

float random01 ();
float random0n (int n);
int tossOfOneDice ();
int tossOfTwoDice ();

#endif