#include <stdio.h>

int main() {
	printf("Bonjour!\nBonne journee\nTravaille bien pour reussir\n");
}
