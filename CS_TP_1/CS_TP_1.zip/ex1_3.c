#include <stdio.h>

int c;

int main() {
	c = getchar();
	printf("%d\n",c);
}
